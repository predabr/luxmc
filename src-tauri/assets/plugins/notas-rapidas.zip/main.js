let notas = [];

function pintar() {
	Luxmc.ui.mount(`
		<div style="display:flex;flex-direction:column;gap:12px">
			<div style="font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:#71717a;font-weight:700">Notas rapidas</div>
			<textarea id="texto" placeholder="Escreve aqui..." style="min-height:150px;resize:vertical;border-radius:10px;border:1px solid rgba(255,255,255,.14);background:rgba(0,0,0,.35);color:#e4e4e7;padding:10px;font:inherit"></textarea>
			<div style="display:flex;gap:8px;align-items:center">
				<button id="salvar" style="height:34px;padding:0 16px;border-radius:10px;border:0;background:#3b82f6;color:#fff;font-weight:600;cursor:pointer">Salvar</button>
				<span id="status" style="font-size:12px;color:#71717a"></span>
			</div>
		</div>
	`);
	const texto = document.getElementById("texto");
	texto.value = notas.join("
");
	document.getElementById("salvar").onclick = async () => {
		notas = texto.value.split("
").filter((linha) => linha.trim());
		await Luxmc.storage.set("notas", JSON.stringify(notas));
		document.getElementById("status").textContent = notas.length + " anotacao(oes) salva(s)";
	};
}

(async () => {
	const salvo = await Luxmc.storage.get("notas");
	try { notas = JSON.parse(salvo ?? "[]"); } catch { notas = []; }
	pintar();
})();
