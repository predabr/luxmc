const CHAVE = "sessoes";
let restante = 25 * 60;
let rodando = false;
let timer = null;

function pintar(sessoes) {
	Luxmc.ui.mount(`
		<div style="display:flex;flex-direction:column;gap:14px">
			<div style="font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:#71717a;font-weight:700">Pomodoro do Luxmc</div>
			<div id="relogio" style="font-size:40px;font-weight:700;font-variant-numeric:tabular-nums;line-height:1">25:00</div>
			<div style="display:flex;gap:8px;flex-wrap:wrap">
				<button id="iniciar" style="height:34px;padding:0 16px;border-radius:10px;border:0;background:#3b82f6;color:#fff;font-weight:600;cursor:pointer">Comecar</button>
				<button id="zerar" style="height:34px;padding:0 14px;border-radius:10px;border:1px solid rgba(255,255,255,.16);background:transparent;color:#e4e4e7;font-weight:600;cursor:pointer">Zerar</button>
			</div>
			<div style="font-size:12px;color:#a1a1aa">Sessoes concluidas: <strong id="total">${sessoes}</strong></div>
		</div>
	`);
	document.getElementById("iniciar").onclick = alternar;
	document.getElementById("zerar").onclick = () => { restante = 25 * 60; parar(); pintar(sessoes); };
}

function parar() {
	rodando = false;
	if (timer) clearInterval(timer);
	timer = null;
	const botao = document.getElementById("iniciar");
	if (botao) botao.textContent = "Comecar";
}

function alternar() {
	if (rodando) { parar(); return; }
	rodando = true;
	document.getElementById("iniciar").textContent = "Pausar";
	timer = setInterval(async () => {
		restante -= 1;
		if (restante <= 0) {
			const sessoes = Number((await Luxmc.storage.get(CHAVE)) ?? "0") + 1;
			await Luxmc.storage.set(CHAVE, String(sessoes));
			Luxmc.ui.toast("Sessao concluida! Total: " + sessoes);
			restante = 25 * 60;
			parar();
			pintar(sessoes);
			return;
		}
		const relogio = document.getElementById("relogio");
		if (relogio) relogio.textContent = Math.floor(restante / 60).toString().padStart(2, "0") + ":" + (restante % 60).toString().padStart(2, "0");
	}, 1000);
}

(async () => { pintar(Number((await Luxmc.storage.get(CHAVE)) ?? "0")); })();
